import React, { Component } from 'react';

class Test4Sub4 extends Component {
    render() {
        return (
            <div className="Test4">
                <div>
                    <h2>설문조사 감사합니다.</h2>
                </div>
            </div>
        );
    }
}

export default Test4Sub4;