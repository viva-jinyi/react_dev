import React, { Component } from 'react';
import Test6 from './components/Test6';

class App extends Component {
  render() {
    return (
      <div>
        <Test6 />
      </div>
    );
  }
}

export default App;